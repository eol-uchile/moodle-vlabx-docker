<?php

defined('MOODLE_INTERNAL') || die();

$string['pluginname'] = '[Cocoon] Users Slider Round';
$string['cocoon_users_slider_round_title'] = 'Title';
$string['cocoon_users_slider_round_users'] = 'Users';
$string['empty'] = 'The list is empty';

$string['cocoon_users_slider_round:addinstance'] = 'Add a cocoon_users_slider_round users block';
$string['cocoon_users_slider_round:myaddinstance'] = 'Add a new cocoon_users_slider_round users to the My Moodle page';
