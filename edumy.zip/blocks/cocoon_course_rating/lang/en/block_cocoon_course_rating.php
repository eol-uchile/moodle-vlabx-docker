<?php
$string['pluginname'] = '[Cocoon] Course Rating';
$string['cocoon_course_rating'] = '[Cocoon] Course Rating';
$string['cocoon_course_rating:addinstance'] = 'Add a new [Cocoon] Course Rating block';
$string['cocoon_course_rating:myaddinstance'] = 'Add a new [Cocoon] Course Rating block to the My Moodle page';
