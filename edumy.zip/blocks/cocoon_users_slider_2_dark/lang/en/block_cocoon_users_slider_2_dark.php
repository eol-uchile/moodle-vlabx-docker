<?php

defined('MOODLE_INTERNAL') || die();

$string['pluginname'] = '[Cocoon] Users Slider Large Dark';
$string['cocoon_users_slider_2_dark_title'] = 'Title';
$string['cocoon_users_slider_2_dark_users'] = 'Users';
$string['empty'] = 'The list is empty';

$string['cocoon_users_slider_2_dark:addinstance'] = 'Add a cocoon_users_slider_2_dark users block';
$string['cocoon_users_slider_2_dark:myaddinstance'] = 'Add a new cocoon_users_slider_2_dark users to the My Moodle page';
