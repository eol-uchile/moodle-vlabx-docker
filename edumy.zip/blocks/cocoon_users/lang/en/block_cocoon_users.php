<?php

defined('MOODLE_INTERNAL') || die();

$string['pluginname'] = '[Cocoon] Users';
$string['cocoon_users_title'] = 'Title';
$string['cocoon_users_users'] = 'Users';
$string['empty'] = 'The list is empty';

$string['cocoon_users:addinstance'] = 'Add a cocoon_users users block';
$string['cocoon_users:myaddinstance'] = 'Add a new cocoon_users users to the My Moodle page';
