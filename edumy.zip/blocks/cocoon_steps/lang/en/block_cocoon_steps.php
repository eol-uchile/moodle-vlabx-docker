<?php

$string['configtitle'] = 'Block title';
$string['cocoon_steps:addinstance'] = 'Add a new [Cocoon] Steps block';
$string['cocoon_steps:myaddinstance'] = 'Add a new [Cocoon] Steps block to Dashboard';
$string['pluginname'] = '[Cocoon] Steps';
