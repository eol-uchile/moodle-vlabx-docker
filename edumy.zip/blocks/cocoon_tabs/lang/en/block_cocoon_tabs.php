<?php

$string['configtitle'] = 'Block title';
$string['cocoon_tabs:addinstance'] = 'Add a new [Cocoon] Tabs block';
$string['cocoon_tabs:myaddinstance'] = 'Add a new [Cocoon] Tabs to Dashboard';
$string['pluginname'] = '[Cocoon] Tabs';
