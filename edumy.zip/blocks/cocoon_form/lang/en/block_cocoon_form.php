<?php
$string['pluginname'] = '[Cocoon] Form';
$string['cocoon_form'] = '[Cocoon] Form';
$string['cocoon_form:addinstance'] = 'Add a new contact form block';
$string['cocoon_form:myaddinstance'] = 'Add a new contact form block to the My Moodle page';
$string['config_title'] = 'Select a form: ';
