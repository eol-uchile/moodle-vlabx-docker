<?php
$string['pluginname'] = '[Cocoon] Hero 6';
$string['cocoon_hero_6'] = '[Cocoon] Hero 6';
$string['cocoon_hero_6:addinstance'] = 'Add a new [Cocoon] Hero 6 block';
$string['cocoon_hero_6:myaddinstance'] = 'Add a new [Cocoon] Hero 6 block to the My Moodle page';
