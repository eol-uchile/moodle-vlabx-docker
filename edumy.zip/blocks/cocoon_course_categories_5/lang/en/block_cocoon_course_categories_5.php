<?php

$string['cocoon_course_categories_5:addinstance'] = 'Add a new courses block';
$string['cocoon_course_categories_5:myaddinstance'] = 'Add a new courses block to Dashboard';
$string['pluginname'] = '[Cocoon] Course categories 5';
$string['config_title'] = 'Title';
$string['config_subtitle'] = 'Subtitle';
$string['config_button_link'] = 'Button link';
