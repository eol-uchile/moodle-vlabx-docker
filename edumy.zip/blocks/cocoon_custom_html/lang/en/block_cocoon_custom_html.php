<?php
$string['pluginname'] = '[Cocoon] Custom HTML';
$string['cocoon_custom_html'] = '[Cocoon] Custom HTML';
$string['cocoon_custom_html:addinstance'] = 'Add a new [Cocoon] Custom HTML block';
$string['cocoon_custom_html:myaddinstance'] = 'Add a new [Cocoon] Custom HTML block to the My Moodle page';
