<?php
$string['pluginname'] = '[Cocoon] Partners';
$string['cocoon_partners'] = '[Cocoon] Partners';
$string['cocoon_partners:addinstance'] = 'Add a new Gallery block';
$string['cocoon_partners:myaddinstance'] = 'Add a new Gallery block to the My Moodle page';
$string['config_title'] = 'Title';
$string['config_subtitle'] = 'Subtitle';
$string['config_image'] = 'Image';
