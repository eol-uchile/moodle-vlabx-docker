<?php
$string['pluginname'] = '[Cocoon] Course Features';
$string['cocoon_course_features'] = '[Cocoon] Course Features';
$string['cocoon_course_features:addinstance'] = 'Add a new Course Features block';
$string['cocoon_course_features:myaddinstance'] = 'Add a new Course Features block to the My Moodle page';
$string['config_title'] = 'Title';
$string['config_lectures'] = 'Lectures';
$string['config_quizzes'] = 'Quizzes';
$string['config_duration'] = 'Duration';
$string['config_skill_level'] = 'Skill level';
$string['config_language'] = 'Language';
$string['config_assessments'] = 'Assessments';
