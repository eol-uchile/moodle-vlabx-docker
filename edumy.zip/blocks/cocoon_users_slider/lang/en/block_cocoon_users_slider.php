<?php

defined('MOODLE_INTERNAL') || die();

$string['pluginname'] = '[Cocoon] Users Slider';
$string['cocoon_users_slider_title'] = 'Title';
$string['cocoon_users_slider_users'] = 'Users';
$string['empty'] = 'The list is empty';

$string['cocoon_users_slider:addinstance'] = 'Add a cocoon_users_slider users block';
$string['cocoon_users_slider:myaddinstance'] = 'Add a new cocoon_users_slider users to the My Moodle page';
